CHESSLEO ACADEMY – PRESS KIT (SIMPLIFIED CHINESE)
As of 12.11.2026

FOLDERS
00_Info          Factsheet, founder story, this file
01_Screenshots   9 screenshots of the app in Simplified Chinese
02_Characters    Coach Bird, Leo, Lina, Grandpa Theo and Titan (transparent PNG or JPG)
03_Logos          App icon 1024 px, transparent logo (PNG), print logo (SVG, JPEG)
04_Key_Visuals    Key visual without text, character banner

USAGE
All images and texts may be used free of charge for editorial coverage of
ChessLeo Academy.

CONTACT
presse@chessleo.de · https://chessleo.de/en/press.html

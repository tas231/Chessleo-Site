CHESSLEO ACADEMY – PRESS KIT (TRADITIONAL CHINESE)
As of 25.11.2026

FOLDERS
00_Info          Factsheet, founder story, this file
01_Screenshots   9 screenshots of the app in Traditional Chinese
02_Characters    Coach Bird, Leo, Lina, Grandpa Theo and Titan (transparent PNG or JPG)
03_Logos          App icon 1024 px, transparent logo (PNG), print logo (SVG, JPEG)
04_Key_Visuals    Key visual without text, character banner

USAGE
All images and texts may be used free of charge for editorial coverage of
ChessLeo Academy. Some screenshots show the “Classic” piece set by Cburnett and
contributors (Wikimedia Commons), which is additionally subject to the BSD 3-Clause
License in LICENSE_Chess_Pieces.txt.

CONTACT
presse@chessleo.de · https://chessleo.de/en/press.html
